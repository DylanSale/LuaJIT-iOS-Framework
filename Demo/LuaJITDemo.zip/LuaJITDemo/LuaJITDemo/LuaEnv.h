//
//  LuaEnv.h
//  LuaJITDemo
//
//  Created by ziggear on 13-7-19.
//  Copyright (c) 2013年 ziggear. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LuaEnv : NSObject
- (int) runLuaScript:(NSString *)filename;
@end
