//
//  LuaEnv.m
//  LuaJITDemo
//
//  Created by ziggear on 13-7-19.
//  Copyright (c) 2013年 ziggear. All rights reserved.
//

#import "LuaEnv.h"
#import <LuaJIT/lua.h>
#import <LuaJIT/lauxlib.h>

int luaj_main();

@implementation LuaEnv

- (id) init {
    self = [super init];
    if(self) {
        // do some init work
    }
    return self;
}

- (int) runLuaScript:(NSString *)filename {
    lua_State *lua = luaL_newstate();
    assert(lua);
    luaL_openlibs(lua);
    
    //const int status = luaL_dostring(lua, "print('hello luajit')");
    const int status = luaL_dofile(lua, [filename cStringUsingEncoding:NSUTF8StringEncoding]);
    if(status)
        printf("Couldn't execute LUA code: %s\n", lua_tostring(lua, -1));
    
    lua_close(lua);
    return 0;
}

@end
