//
//  AppDelegate.h
//  LuaJITDemo
//
//  Created by ziggear on 13-7-18.
//  Copyright (c) 2013年 ziggear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
